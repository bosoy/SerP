﻿class MortarTime	{
		title = "Время ремонта миномёта";
		values[] = {60,120,300,600};
		texts[] = {"1 min","2 min","5 min","10 min"};
		default = 300;
		code = "MortarTime = %1";
 };
