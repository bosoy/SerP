﻿class BigBrother	{
	title = "$STR_BigBrother";
	values[] = {1,0};
	texts[] = {$STR_On,$STR_Off};
	default = 0;
	code = "BigBrother = %1";
};