	class timeOfDay {
		title = "$STR_timeOfDay";
		values[] = {0,1,2,3,4,5,6,7};
		texts[] = {$STR_timeOfDay_Option0,$STR_timeOfDay_Option1,$STR_timeOfDay_Option2,$STR_timeOfDay_Option3,$STR_timeOfDay_Option4,$STR_timeOfDay_Option5,$STR_timeOfDay_Option6,$STR_timeOfDay_Option7};
		default = 1;
		code = "timeOfDay = %1";
	};
	class weather {
		title = "$STR_weather";
		values[] = {0,1,2,3,4};
		texts[] = {$STR_weather_Option0,$STR_weather_Option1,$STR_weather_Option2,$STR_weather_Option3,$STR_weather_Option4};
		default = 1;
		code = "weather = %1";
	};