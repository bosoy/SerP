class Header	{
	gameType = Unknown;
	minPlayers = 1;
	maxPlayers = 80;
};
respawn = 1;
respawndelay = 3;